//
//  ViewController.swift
//  TrollBoard
//
//  Created by Awolowo Mayungbe on 5/28/17.
//  Copyright © 2017 Awolowo Mayungbe. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    let soundNames = ["I cant do it now", "Oh my gawdd","I called Him Daddy","Wut duh fuckkk", "Rodolfo guess what I did today","I changed my major", "Awo A Bitch"]
    var soundBoards = [AVAudioPlayer]()
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    //setup audio player
        
        for sound in soundNames {
            
            do{
                // Do something
                
                
                
                let url = URL(fileURLWithPath: Bundle.main.path(forResource: sound ,ofType: "m4a")!)
                
                let soundBoard =  try AVAudioPlayer(contentsOf: url as URL)
                
                soundBoards.append(soundBoard)
                
                
            }
                
                
            catch {
                
                // Catch the error
                
                soundBoards.append(AVAudioPlayer())
            }
            
            
           
        }
    
    
    
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func buttonTap(_ sender: UIButton) {
        
        let soundBoard = soundBoards[sender.tag]
        soundBoard.play()
    }
}

